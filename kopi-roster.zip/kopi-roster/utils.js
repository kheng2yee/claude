function fmtShift(s) {
  var p = s.split("-");
  var a = p[0].split(":");
  var b = p[1].split(":");
  var h1 = parseInt(a[0]);
  var h2 = parseInt(b[0]);
  var ap1 = h1 >= 12 ? "pm" : "am";
  var ap2 = h2 >= 12 ? "pm" : "am";
  if (h1 > 12) h1 = h1 - 12;
  if (h2 > 12) h2 = h2 - 12;
  return h1 + ap1 + " - " + h2 + ap2;
}

function formatShiftTime(shift) {
  var parts = shift.split("-");
  var start = parts[0].split(":");
  var end = parts[1].split(":");
  var sh = parseInt(start[0]);
  var eh = parseInt(end[0]);
  var sap = sh >= 12 ? "pm" : "am";
  var eap = eh >= 12 ? "pm" : "am";
  if (sh > 12) sh = sh - 12;
  if (eh > 12) eh = eh - 12;
  return sh + sap + " - " + eh + eap;
}

function countStaff(list) {
  var c = 0;
  for (var i = 0; i < list.length; i++) { c = c + 1; }
  return c;
}
