# Kopi Corner Roster

Roster app for the 4 staff at Kopi Corner.

## How to run

1. Run `npm install`
2. Run `npm start`
3. Go to http://localhost:3000

## Features

- Shows the roster for the week
- Import roster from Excel (Roster.xlsx)
- Admin password is "admin"

Last updated: March 2024
