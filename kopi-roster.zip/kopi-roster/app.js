var ADMIN_PASS = "kopi123";
var days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

function drawTable() {
  var tbl = document.getElementById("roster");
  var html = "<tr><th>Staff</th><th>Role</th>";
  for (var i = 0; i < days.length; i++) {
    html += "<th>" + days[i] + "</th>";
  }
  html += "</tr>";
  for (var j = 0; j < STAFF_DATA.length; j++) {
    var s = STAFF_DATA[j];
    html += "<tr><td class='name'>" + s.nm + "</td><td>" + s.role + "</td>";
    for (var k = 0; k < days.length; k++) {
      var sh = s.shifts[days[k]];
      if (sh == "OFF") {
        html += "<td class='off'>OFF</td>";
      } else {
        html += "<td>" + fmtShift(sh) + "</td>";
      }
    }
    html += "</tr>";
  }
  tbl.innerHTML = html;
  document.getElementById("msg").innerText = "";
}

function showWeekend() {
  var wkDays = ["Sat", "Sun"];
  var t = document.getElementById("roster");
  var h = "<tr><th>Staff</th><th>Role</th>";
  for (var x = 0; x < wkDays.length; x++) {
    h += "<th>" + wkDays[x] + "</th>";
  }
  h += "</tr>";
  for (var y = 0; y < STAFF_DATA.length; y++) {
    var st = STAFF_DATA[y];
    h += "<tr><td class='name'>" + st.nm + "</td><td>" + st.role + "</td>";
    for (var z = 0; z < wkDays.length; z++) {
      var shf = st.shifts[wkDays[z]];
      if (shf == "OFF") {
        h += "<td class='off'>OFF</td>";
      } else {
        h += "<td>" + formatShiftTime(shf) + "</td>";
      }
    }
    h += "</tr>";
  }
  t.innerHTML = h;
  document.getElementById("msg").innerText = "";
}

function editShift() {
  var pw = prompt("Admin password:");
  if (pw != ADMIN_PASS) {
    alert("Wrong password");
    return;
  }
  var who = prompt("Staff name?");
  var d = prompt("Day? (Mon, Tue, Wed, Thu, Fri, Sat, Sun)");
  var newShift = prompt("New shift (e.g. 07:00-15:00) or OFF");
  for (var i = 0; i < STAFF_DATA.length; i++) {
    if (STAFF_DATA[i].nm == who) {
      STAFF_DATA[i].shifts[d] = newShift;
    }
  }
  drawTable();
  document.getElementById("msg").innerHTML = "Updated " + who + " on " + d;
}

drawTable();
