var STAFF_DATA = [
  { nm: "Aisyah", role: "Barista", shifts: { Mon: "07:00-15:00", Tue: "07:00-15:00", Wed: "OFF", Thu: "07:00-15:00", Fri: "07:00-15:00", Sat: "10:00-18:00", Sun: "OFF" } },
  { nm: "Kumar", role: "Barista", shifts: { Mon: "10:00-18:00", Tue: "OFF", Wed: "10:00-18:00", Thu: "10:00-18:00", Fri: "OFF", Sat: "07:00-15:00", Sun: "07:00-12:00" } },
  { nm: "Mei Ling", role: "Cashier", shifts: { Mon: "07:00-13:00", Tue: "07:00-13:00", Wed: "07:00-13:00", Thu: "OFF", Fri: "07:00-13:00", Sat: "OFF", Sun: "12:00-18:00" } },
  { nm: "Hafiz", role: "Kitchen", shifts: { Mon: "OFF", Tue: "07:00-15:00", Wed: "07:00-15:00", Thu: "07:00-15:00", Fri: "07:00-15:00", Sat: "07:00-15:00", Sun: "OFF" } },
  { nm: "Priya", role: "Kitchen", shifts: { Mon: "10:00-18:00", Tue: "10:00-18:00", Wed: "OFF", Thu: "OFF", Fri: "10:00-18:00", Sat: "10:00-18:00", Sun: "10:00-18:00" } },
  { nm: "Daniel", role: "Supervisor", shifts: { Mon: "09:00-17:00", Tue: "09:00-17:00", Wed: "09:00-17:00", Thu: "09:00-17:00", Fri: "09:00-17:00", Sat: "09:00-13:00", Sun: "OFF" } }
];
