var pass = "admin";
var staff = [
  ["Aisyah", "Barista", "7-3", "7-3", "OFF", "7-3", "7-3", "10-6", "OFF"],
  ["Kumar", "Barista", "10-6", "OFF", "10-6", "10-6", "OFF", "7-3", "7-3"],
  ["Mei Ling", "Cashier", "7-1", "7-1", "7-1", "OFF", "7-1", "OFF", "12-6"],
  ["Hafiz", "Kitchen", "OFF", "7-3", "7-3", "7-3", "7-3", "7-3", "OFF"]
];

function showRoster() {
  var out = "<table border='1'>";
  for (var i = 0; i < staff.length; i++) {
    out += "<tr>";
    for (var j = 0; j < staff[i].length; j++) {
      out += "<td>" + staff[i][j] + "</td>";
    }
    out += "</tr>";
  }
  out += "</table>";
  document.write(out);
}

showRoster();
